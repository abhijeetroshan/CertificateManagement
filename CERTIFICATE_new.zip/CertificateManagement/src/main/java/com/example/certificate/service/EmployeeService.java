package com.example.certificate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.certificate.model.*;
import com.example.certificate.model.Employee;
import com.example.certificate.repository.IEmployeeRepo;

@Service
public class EmployeeService {
	@Autowired
	private IEmployeeRepo employeeRepo;
	
	//insert new employee data
	public Employee create(Employee e) {
		return employeeRepo.save(e);
	}
	
	
	//get employee list
	public List<Employee> getAll(){
		return (List<Employee>) employeeRepo.findAll();
	}


	public Employee findById(String emplId) {
		// TODO Auto-generated method stub
		return employeeRepo.findById(emplId).get();
	}
	
	
	//update certificate for particular employee
	public Employee Update(String emplId,EmpCertificate c) {
		Employee e=findById(emplId);
		e.getCertificates().add(c);
		return employeeRepo.save(e);
	}
	

}
