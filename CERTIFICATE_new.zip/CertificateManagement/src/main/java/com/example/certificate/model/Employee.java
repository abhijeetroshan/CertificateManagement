package com.example.certificate.model;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Employee")
public class Employee {

@Id
private String emplId;

private String empName;
private String password;
private String role;

private List<Certificate> certificates;

public Employee() {
	super();
}

public Employee(String emplId, String empName, String password, String role, List<Certificate> certificates) {
	super();
	this.emplId = emplId;
	this.empName = empName;
	this.password = password;
	this.role = role;
	this.certificates = certificates;
}

public Employee(String emplId, String empName, String password, String role) {
	super();
	this.emplId = emplId;
	this.empName = empName;
	this.password = password;
	this.role = role;
}

public Employee(Certificate certificate) {
      this.certificates.add(certificate);
}

public String getEmplId() {
	return emplId;
}
public void setEmplId(String emplId) {
	this.emplId = emplId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}

public List<Certificate> getCertificates() {
	return certificates;
}

public void setCertificates(List<Certificate> certificates) {
	this.certificates = certificates;
}

@Override
public String toString() {
	return "Employee [emplId=" + emplId + ", empName=" + empName + ", password=" + password + ", role=" + role
			+ ", certificates=" + certificates + "]";
}



}
