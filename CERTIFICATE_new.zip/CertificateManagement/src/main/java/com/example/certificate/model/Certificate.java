package com.example.certificate.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Document(collection="Certificate")
public class Certificate {
	@Id
private String certificateName;
private Date startDate;
private Date endDate;
private int count;

public Certificate() {
	super();
}
public Certificate(String certificateName, Date startDate, Date endDate, int count) {
	super();
	this.certificateName = certificateName;
	this.startDate = startDate;
	this.endDate = endDate;
	this.count = count;
}
public String getCertificateName() {
	return certificateName;
}
public void setCertificateName(String certificateName) {
	this.certificateName = certificateName;
}
public Date getStartDate() {
	return startDate;
}
public void setStartDate(Date startDate) {
	this.startDate = startDate;
}
public Date getEndDate() {
	return endDate;
}
public void setEndDate(Date endDate) {
	this.endDate = endDate;
}

public int getStatus() {
	return count;
}
public void setStatus(int count) {
	this.count = count;
}
@Override
public String toString() {
	return "Certificate [certificateName=" + certificateName + ", startDate=" + startDate + ", endDate=" + endDate
			+ "]";
}
 


}
