package com.example.certificate.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.certificate.model.Certificate;
import com.example.certificate.model.EmpCertificate;
import com.example.certificate.model.Employee;
import com.example.certificate.service.CertificateService;
import com.example.certificate.service.EmployeeService;

@Controller
public class CertificateController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private CertificateService certificateService;

	@Autowired
	private PasswordEncoder passwordEncoder;

	// First Page

	@RequestMapping("/")
	public String welcome(@ModelAttribute("t") Employee e) {
		return "welcome";
	}

	// profile

	@RequestMapping("/profile")
	public String profile(HttpSession session, ModelMap m) {

		Employee emp = employeeService.searchById(session.getAttribute("username").toString());
		m.addAttribute("profileInfo", emp);
		return "profile";
	}

	// Add Certificate
	@RequestMapping("/addCert")
	public String addCert(@ModelAttribute("c") Certificate c, ModelMap m, HttpSession session) {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());
		return "AddCert";
	}

	@RequestMapping(value = "/addCert", method = RequestMethod.POST)
	public String addCertPost(@ModelAttribute("c") Certificate c, ModelMap m, HttpSession session)
			throws ParseException {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());

		String msg = certificateService.validateDate(c.getStartDate(), c.getEndDate());
		if (!msg.equalsIgnoreCase("success")) {
			m.addAttribute("msg", msg);
			m.addAttribute("error", true);
			return "AddCert";
		}

		// Validate Certificate
		if (certificateService.searchById(c.getCertificateName()) == null) {
			c.setStatus("Active");
			certificateService.create(c);
			m.addAttribute("msg", "Added Successfully!!");
			m.addAttribute("error", false);
			return "AddCert";
		}

		m.addAttribute("msg", "Already exist!!");
		m.addAttribute("error", true);
		return "AddCert";
	}

	// Assign Certificate

	@RequestMapping("/assignCert")
	public String assignCert(@ModelAttribute("e") Employee e, ModelMap m, HttpSession session) {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());
		ArrayList<Certificate> cList = (ArrayList<Certificate>) certificateService.getAll();
		m.addAttribute("clist", cList);
//		System.out.println(cList);
		ArrayList<Employee> eList = (ArrayList<Employee>) employeeService.getAll();
//		eList.remove(1);
		Employee e1 = employeeService.searchById(session.getAttribute("username").toString());
//		System.out.println(e1);
		eList.remove((Object) e1);
		m.addAttribute("elist", eList);
//		System.out.println(eList);
		return "AssignCert";
	}

	@RequestMapping(value = "/assignCert", method = RequestMethod.POST)
	public String assignCertPost(@ModelAttribute("e") Employee e, ModelMap m, HttpSession session) {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());

		System.out.println("in Assign Cert: " + e);

		// dynamic input assignment
		ArrayList<Certificate> cList = (ArrayList<Certificate>) certificateService.getAll();
		m.addAttribute("clist", cList);
//   		System.out.println(cList);
		ArrayList<Employee> eList = (ArrayList<Employee>) employeeService.getAll();
		eList.remove(1);
		m.addAttribute("elist", eList);
//   		System.out.println(eList);

		// data posting
		Certificate cert = certificateService.searchById(e.getEmpName());
		System.out.println(cert);
		Employee emp = employeeService.searchById(e.getEmplId());
		System.out.println(emp.getCertificates());

		if (cert.getAssignCount() < cert.getCount()) {
			EmpCertificate ec = new EmpCertificate(cert.getCertificateName(), cert.getStartDate(), cert.getEndDate(),
					"pending");
			boolean duplicate = false;
			for (EmpCertificate fetch : emp.getCertificates()) {
				if (fetch.getCertificateName().equals(cert.getCertificateName())) {
					duplicate = true;
					break;
				}
			}
			if (cert.getStatus().equalsIgnoreCase("Expired")) {
				m.addAttribute("msg", cert.getCertificateName() + " certification has Expired!!");
				return "AssignCert";
			}
			if (duplicate) {
				m.addAttribute("msg", "Already Assigned!!");
				return "AssignCert";
			}

			emp.getCertificates().add(ec);
			employeeService.create(emp);
			int assignCount = cert.getAssignCount();
			cert.setAssignCount(assignCount + 1);
			certificateService.create(cert);
			System.out.println(emp.getCertificates());
			m.addAttribute("msg", "Assigned Successfully!!");
			return "AssignCert";
		}
		m.addAttribute("msg", "Cannot Assign. " + cert.getCertificateName() + " certification limit exceed. ");
		return "AssignCert";
	}

	// Update Certificate
	@RequestMapping("/updateCert")
	public String updateCert(@ModelAttribute("c") Certificate c, ModelMap m, HttpSession session) {

		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());

		ArrayList<Certificate> cList = (ArrayList<Certificate>) certificateService.getAll();
		cList.removeIf(cert -> (cert.getStatus().equalsIgnoreCase("active")));

		/*
		 * for (Certificate cert : cList) { if
		 * (cert.getStatus().equalsIgnoreCase("active")) { // int i =
		 * cList.indexOf(cert); cList.remove(cert);
		 * 
		 * } }
		 */System.out.println(cList);

		m.addAttribute("expiredCert", true);
		if (cList.isEmpty())
			m.addAttribute("expiredCert", false);

		m.addAttribute("clist", cList);
		System.out.println(cList);
		return "UpdateCert";
	}

	@RequestMapping(value = "/updateCert", method = RequestMethod.POST)
	public String updateCertPost(@ModelAttribute("c") Certificate c, ModelMap m, HttpSession session)
			throws ParseException {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());
		String msg = "";
		msg = certificateService.validateDate(c.getStartDate(), c.getEndDate());
		System.out.println("Date Validation msg: " + msg);
		if (!msg.equals("success")) {
			m.addAttribute("msg", msg);
			m.addAttribute("error", true);
			return "UpdateCert";
		}
		// Validate Certificate
		c.setStatus("Active");
		System.out.println(c);
		certificateService.create(c);
		ArrayList<Certificate> cList = (ArrayList<Certificate>) certificateService.getAll();
		m.addAttribute("clist", cList);
		m.addAttribute("msg", "Updated Successfully!!");
		m.addAttribute("error", false);
		return "UpdateCert";

	}

	// Remove Certificate

	@RequestMapping("/removeCert")
	public String removeCert(@ModelAttribute("c") Certificate c, ModelMap m, HttpSession session) {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());

		ArrayList<Certificate> cList = (ArrayList<Certificate>) certificateService.getAll();
		m.addAttribute("clist", cList);
		System.out.println(cList);
		return "RemoveCert";
	}

	@SuppressWarnings("null")
	@RequestMapping(value = "/removeCert", method = RequestMethod.POST)
	public String removeCertPost(@ModelAttribute("c") Certificate c, ModelMap m, HttpSession session) {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());
//		certificateService.remove(c.getCertificateName());
//		EmpCertificate newCertificate;
		List<Employee> e = employeeService.getAll();
		e.remove(0);
		for (Employee employee : e) {
//			newCertificate.clear();
			for (EmpCertificate certificate : employee.getCertificates()) {
				System.out.println("Inside certificate " + certificate);
				if (certificate.getCertificateName().equalsIgnoreCase(c.getCertificateName()) && certificate.getStatus().equalsIgnoreCase("Pending")) {
					int i = employee.getCertificates().indexOf(certificate);
					employee.getCertificates().get(i).setStatus("Terminated");
				}
				employeeService.create(employee);

			}
		}

		/*
		 * for (Employee employee : e) { EmpCertificate empCert=(EmpCertificate)
		 * employee.getCertificates().stream() .filter(cert ->
		 * cert.getCertificateName().equalsIgnoreCase(c.getCertificateName())) .collect(
		 * Collectors.toList()).get(0);
		 * 
		 * System.out.println("empcert:  "+empCert); if(empCert != null) {
		 * 
		 * employee.getCertificates().get(employee.getCertificates().indexOf(empCert)).
		 * setStatus("terminated"); System.out.println("Employee:  "+employee); //
		 * employeeService.create(employee); } }
		 */
		ArrayList<Certificate> cList = (ArrayList<Certificate>) certificateService.getAll();
		m.addAttribute("clist", cList);
		// send msg to employee that certification was cancelled. and remove out this
		// certificate data from employeedata and show them removed certificate details.
		m.addAttribute("msg", "Deleted Successfully!!");
		return "RemoveCert";

	}

	// Admin: teammates

	@RequestMapping("/teammates")
	public String allTeamMember(@ModelAttribute("t") Employee e, HttpSession session, ModelMap m) {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());

		List<Employee> l = (List<Employee>) employeeService.getAll();
		l.remove(1);
		System.out.println(session.getAttribute("username"));
		List<Integer> count = new ArrayList<>();
		for (int i = 1; i <= l.size(); i++)
			count.add(i);
		m.addAttribute("count", count);
		m.addAttribute("l", l);
		return "teammates";
	}

	// dashboard
	@RequestMapping(value = { "/index" }, method = RequestMethod.POST)
	public String checkLogin(@ModelAttribute("t") Employee e, ModelMap m, @ModelAttribute("c") Certificate c,
			HttpSession session) {

		System.out.println(e);
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("ENGLISH", "India"));
		String currDate = simpleDateFormat.format(new Date());
		System.out.println(currDate);

		Employee em = employeeService.searchById(e.getEmplId());
		// System.out.println("Hiii"+em);
		if (em != null) {
			if (passwordEncoder.matches(e.getPassword(), em.getPassword())) {

				session.setAttribute("username", em.getEmplId());
				if (em.getRole().equalsIgnoreCase("ADMIN")) {
					int tcount = 0, acount = 0;
					List<Certificate> l = new ArrayList<Certificate>();
					l = certificateService.getAll();
					for (Certificate i : l) {
						tcount += i.getCount();
						acount += i.getAssignCount();
						if (i.getEndDate().compareTo(currDate) < 0)
							if (i.getStatus().equalsIgnoreCase("Active")) {
								i.setStatus("Expired");
								certificateService.create(i);
							}
						if (i.getStatus().equalsIgnoreCase("Expired")) {
							i.setLapsedCount(i.getCount() - i.getAssignCount());
							certificateService.create(i);
						}
					}

					// lapse certificate

					// System.out.println(l.remove(0));
					m.addAttribute("admin", em);
					m.addAttribute("tcount", tcount);
					m.addAttribute("acount", acount);
					m.addAttribute("dcount", tcount - acount);
					m.addAttribute("l", l);
//					 System.out.println("tcount: "+tcount);

//					 System.out.println("acount: "+acount);
					// System.out.println("admin part:" + l);
					return "index";
				} else {
					int aCount = 0, pCount = 0;
					for (EmpCertificate eCert : em.getCertificates()) {
						aCount++;
						if (eCert.getStatus().equalsIgnoreCase("pending"))
							pCount++;
					}

					m.addAttribute("emp", em);
					m.addAttribute("aCount", aCount);
					m.addAttribute("pCount", pCount);
					m.addAttribute("cCount", aCount - pCount);
					System.out.println("user part:" + em);
					return "employee";
				}
			} else {
				m.addAttribute("msg", "Wrong Credentials.");
				return "welcome";
			}
		} else {
			m.addAttribute("msg", "User doesn't Exist.");
			return "welcome";
		}
	}

	@RequestMapping(value = "/cert/{id}", method = RequestMethod.GET)
	public String getCertificates(@PathVariable("id") String id, ModelMap m, HttpSession session) {
		m.addAttribute("username",
				employeeService.searchById(session.getAttribute("username").toString()).getEmpName());

		Employee e = employeeService.searchById(id);
		m.addAttribute("emp", e);
		return "certificate";
	}

	// get all the certificates assign to particular employee
	@RequestMapping(value = "/cert/{id}", method = RequestMethod.POST)
	public String updateCertificatesList(@PathVariable("id") String id, @ModelAttribute("t") EmpCertificate c,
			ModelMap m) {
		System.out.println("certificate to add: " + c);
		Employee e = employeeService.Update(id, c);
		System.out.println("Update:  " + e);
		m.addAttribute("emp", e);
		return "certificate";
	}

	// dashboard
	@RequestMapping(value = { "/index" }, method = RequestMethod.GET)
	public String checkedLogin(@ModelAttribute("t") Employee e, ModelMap m, @ModelAttribute("c") Certificate c,
			HttpSession session) {
		Employee em = employeeService.searchById(session.getAttribute("username").toString());
		// System.out.println(l.remove(0));
		if (em.getRole().equalsIgnoreCase("ADMIN")) {
			int tcount = 0, acount = 0;
			List<Certificate> l = new ArrayList<Certificate>();
			l = certificateService.getAll();
			for (Certificate i : l) {
				tcount += i.getCount();
				acount += i.getAssignCount();
			}
			// System.out.println(l.remove(0));
			m.addAttribute("admin", em);
			m.addAttribute("tcount", tcount);
			m.addAttribute("acount", acount);
			m.addAttribute("dcount", tcount - acount);
			m.addAttribute("l", l);
			return "index";
		} else {
			int aCount = 0, pCount = 0;
			for (EmpCertificate eCert : em.getCertificates()) {
				aCount++;
				if (eCert.getStatus().equalsIgnoreCase("pending"))
					pCount++;
			}

			m.addAttribute("emp", em);
			m.addAttribute("aCount", aCount);
			m.addAttribute("pCount", pCount);
			m.addAttribute("cCount", aCount - pCount);
			System.out.println("user part:" + em);
			return "employee";
		}

	}

	@RequestMapping("/charts")
	String charts(HttpSession session) {
		Employee e = employeeService.searchById((String) session.getAttribute("username"));
		if (e.getRole().equalsIgnoreCase(("admin")))
			return "AdminCharts";

		return "UserCharts";
	}

	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.removeAttribute("username");
		return "redirect:/";
	}
	
	@RequestMapping("*")
	public String errorPage() {
		return "404";
	}
}
