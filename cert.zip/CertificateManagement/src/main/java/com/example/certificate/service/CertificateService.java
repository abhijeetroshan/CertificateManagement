package com.example.certificate.service;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.certificate.model.Certificate;
import com.example.certificate.repository.ICertificateRepo;

@Service
public class CertificateService {

	@Autowired
	ICertificateRepo certificateRepo;

	// validate dates
	public String validateDate(String startDate, String EndDate) {
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("ENGLISH", "India"));

		String currDate = simpleDateFormat.format(new Date());

		if (startDate.compareTo(currDate) < 0 || EndDate.compareTo(currDate) < 0) {
			return " Selected date is passed !!";

		}
		if (startDate.compareTo(EndDate) == 0) {
			return startDate + " Start date and End date cannot be same!!";

		}

		LocalDate d1 = LocalDate.parse(startDate, DateTimeFormatter.ISO_LOCAL_DATE);
		LocalDate d2 = LocalDate.parse(EndDate, DateTimeFormatter.ISO_LOCAL_DATE);

		if (d1.isAfter(d2)) {
			return startDate + " must be before " + EndDate + " !!";
		}
		Duration diff = Duration.between(d1.atStartOfDay(), d2.atStartOfDay());
		long diffDays = diff.toDays();
		if (diffDays <= 30) {
			return EndDate + " Duration must be of 30 days!!";
		}

		return "success";
	}

	// save certificate
	public void create(Certificate e) {
		certificateRepo.save(e);
	}

	// get Certificate list
	public List<Certificate> getAll() {
		return (List<Certificate>) certificateRepo.findAll();
	}

	// search certificate
	public Certificate searchById(String Id) {
		// TODO Auto-generated method stub
		return certificateRepo.findById(Id).orElse(null);
	}

	public void remove(String certificateName) {
		// TODO Auto-generated method stub
		 certificateRepo.removeByCertificateName(certificateName);
	}

}
