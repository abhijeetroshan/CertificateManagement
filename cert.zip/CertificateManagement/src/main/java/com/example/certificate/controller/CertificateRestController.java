package com.example.certificate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.certificate.model.Employee;
import com.example.certificate.service.EmployeeService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/cert")
public class CertificateRestController {
	
	
	@Autowired
	EmployeeService employeeService;

	@Autowired
	PasswordEncoder passwordEncoder;

	
	// Adding data to MongoDB
		@PostMapping("/create")
		public Employee Create() {
			/*
			 * String pattern = "yyyy-MM-dd"; SimpleDateFormat simpleDateFormat = new
			 * SimpleDateFormat(pattern);
			 * 
			 * String sd = simpleDateFormat.format("2018-05-25"); String ed =
			 * simpleDateFormat.format("2018-07-25"); System.out.println(sd);
			 */

			// Certificate data

//			 Certificate c=new Certificate("java","2019-01-25","2019-05-25",10);
//			 c.setAssignCount(2);
//			 Certificate c1=new Certificate("AWS","2018-05-25","2018-07-25",9);
//			 c1.setAssignCount(2);
//			Certificate c = certificateService.searchById("java");
//			Certificate c1 = certificateService.searchById("AWS");
//			Certificate c2 = certificateService.searchById("Apache");
//			Certificate c3 = certificateService.searchById("Machine Learning & NLP");
//			Certificate c4 = certificateService.searchById("Azure");
//			c.setStatus("Active");
//			c1.setStatus("Active");
//			c2.setStatus("Active");
//			c3.setStatus("Active");
//			c4.setStatus("Active");
//			certificateService.create(c);
//			certificateService.create(c1);

//			 Certificate c2=new Certificate("Apache","2019-05-02","2019-10-02",2);
//			 c2.setAssignCount(2);
//			certificateService.create(c2);
//			certificateService.create(c3);
//			certificateService.create(c4);

			// User Data

//			EmpCertificate c = new EmpCertificate("java", "2019-01-25", "2019-05-25", "Pending");
//			EmpCertificate c1 = new EmpCertificate("AWS", "2018-05-25", "2018-07-25", "Completed");
//			ArrayList l = new ArrayList<>();
//			l.add(c);
//			l.add(c1);
			Employee e = new Employee("161017", "Abhijeet", passwordEncoder.encode("161017"), "User");

			return employeeService.create(e);

			// admin data

			
//			  Employee e = new Employee("161018", "Carel", passwordEncoder.encode("161017"), "Admin");
//			  return employeeService.create(e);
			 

		}
		
		// Checking MongoDB data
		@GetMapping("/get")
		public List<Employee> get() {
			return employeeService.getAll();
//			return iCertificateRepo.findAll().toString(`);

		}
		@GetMapping("/check")
		public Employee welcome(@RequestParam("emplId")String emplId,@RequestParam("password")String password) {
			Employee employee = employeeService.searchById(emplId);
			System.out.println("check"+employee);
			return employee;
		}
		
}
