package com.example.certificate.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Certificate")
public class Certificate {
@Id
private String certificateName;
private String startDate;
private String endDate;
private String status;
private int count;
private int assignCount;
private int lapsedCount;


public Certificate() {
	super();

}

public Certificate(String certificateName, String startDate, String endDate, int count) {
	super();
	this.certificateName = certificateName;
	this.startDate = startDate;
	this.endDate = endDate;
	this.count = count;
	this.assignCount=0;
	this.status="Active";
	this.lapsedCount=0;
}

public int getLapsedCount() {
	return lapsedCount;
}

public void setLapsedCount(int lapsedCount) {
	this.lapsedCount = lapsedCount;
}

public String getCertificateName() {
	return certificateName;
	
}
public void setCertificateName(String certificateName) {
	this.certificateName = certificateName;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}


public int getAssignCount() {
	return assignCount;
}

public void setAssignCount(int assignCount) {
	this.assignCount = assignCount;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}


@Override
public String toString() {
	return "Certificate [certificateName=" + certificateName + ", startDate=" + startDate + ", endDate=" + endDate
			+ ", count=" + count + ", assignCount=" + assignCount + "status= "+ status+ "lapsed="+lapsedCount+"]";
}



}
