package com.example.certificate.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.certificate.model.Certificate;

public interface ICertificateRepo extends MongoRepository<Certificate,String>{
	
	@DeleteQuery
	public void removeByCertificateName(String certificateName);
	
    
}
