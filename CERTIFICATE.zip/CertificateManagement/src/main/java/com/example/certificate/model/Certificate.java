package com.example.certificate.model;

import java.util.Date;

import org.springframework.stereotype.Component;

public class Certificate {
private String certificateName;
private String startDate;
private String endDate;
private String status;

public Certificate() {
	super();
}
public Certificate(String certificateName, String startDate, String endDate, String status) {
	super();
	this.certificateName = certificateName;
	this.startDate = startDate;
	this.endDate = endDate;
	this.status = status;
}
public String getCertificateName() {
	return certificateName;
}
public void setCertificateName(String certificateName) {
	this.certificateName = certificateName;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}

public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "Certificate [certificateName=" + certificateName + ", startDate=" + startDate + ", endDate=" + endDate
			+ ", status=" + status + "]";
}
 


}
